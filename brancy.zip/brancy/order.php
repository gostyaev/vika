<?php
require 'connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Пользователь не авторизован']);
    exit;
}

$user_id = $_SESSION['user_id'];
$total_price = isset($_POST['total_price']) ? floatval($_POST['total_price']) : 0.00;

if ($total_price <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Некорректная сумма заказа']);
    exit;
}

// Добавляем заказ в таблицу orders
$sql = "INSERT INTO orders (user_id, total_price, status) VALUES (?, ?, 'pending')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("id", $user_id, $total_price);

if ($stmt->execute()) {
    // Очистка корзины после оформления заказа
    $clearCartSql = "DELETE FROM cart WHERE user_id = ?";
    $clearCartStmt = $conn->prepare($clearCartSql);
    $clearCartStmt->bind_param("i", $user_id);
    $clearCartStmt->execute();
    $clearCartStmt->close();

    echo json_encode(['status' => 'success', 'message' => 'Заказ успешно оформлен']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Ошибка при оформлении заказа']);
}

$stmt->close();
$conn->close();
?>
