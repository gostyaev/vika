<?php
session_start();

// Проверка, есть ли сессия пользователя (если нет, то редирект на страницу входа)
if (!isset($_SESSION['user_id'])) {
    echo "Ошибка: Пользователь не авторизован.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id'])) {
    $product_id = $_POST['product_id'];
    $user_id = $_SESSION['user_id'];  // Получаем ID пользователя из сессии

    // Подключение к базе данных
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user_auth";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Удаление товара из корзины
    $deleteQuery = "DELETE FROM cart WHERE user_id = ? AND product_id = ?";
    $stmt = $conn->prepare($deleteQuery);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();

    // Закрываем соединение с базой данных
    $stmt->close();
    $conn->close();

    // Ответ для AJAX
    echo "Товар удален из корзины.";
    exit();
}
?>
