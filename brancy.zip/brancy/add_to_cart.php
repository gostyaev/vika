<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    echo "Пользователь не авторизован";
    exit();
}

$user_id = $_SESSION['user_id'];
$product_id = $_POST['product_id'];

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_auth";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Проверка, есть ли товар уже в корзине
$sql_check = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("ii", $user_id, $product_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    // Если товар уже есть в корзине, увеличиваем количество
    $sql_update = "UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ii", $user_id, $product_id);
    $stmt_update->execute();
} else {
    // Если товара нет в корзине, добавляем новый товар
    $sql_add = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, 1)";
    $stmt_add = $conn->prepare($sql_add);
    $stmt_add->bind_param("ii", $user_id, $product_id);
    $stmt_add->execute();
}

$stmt_check->close();
$stmt_update->close();
$stmt_add->close();
$conn->close();

echo "Товар добавлен в корзину";
?>
