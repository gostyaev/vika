<?php
session_start();

// Проверка, есть ли сессия пользователя (если нет, то редирект на страницу входа)
if (!isset($_SESSION['user_id'])) {
    header("Location: account-login.php");
    exit();
}

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_auth";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получаем все товары из корзины текущего пользователя
$user_id = $_SESSION['user_id'];
$sql = "SELECT cart.id, cart.quantity, products.name, products.price
        FROM cart
        JOIN products ON cart.product_id = products.id
        WHERE cart.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$total_price = 0;

echo '<h2>Оформление заказа</h2>';
echo '<table>';
echo '<thead><tr><th>Товар</th><th>Цена</th><th>Количество</th><th>Итого</th></tr></thead>';
echo '<tbody>';
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $productName = $row['name'];
        $productPrice = $row['price'];
        $quantity = $row['quantity'];
        $subtotal = $productPrice * $quantity;
        $total_price += $subtotal;

        echo '<tr>';
        echo '<td>' . $productName . '</td>';
        echo '<td>' . $productPrice . ' р</td>';
        echo '<td>' . $quantity . '</td>';
        echo '<td>' . $subtotal . ' р</td>';
        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="4">Ваша корзина пуста.</td></tr>';
}
echo '</tbody>';
echo '</table>';
echo '<p>Общая сумма: ' . $total_price . ' р</p>';

// Кнопка для оформления заказа
echo '<form method="POST" action="create_order.php">';
echo '<input type="hidden" name="total_price" value="' . $total_price . '">';
echo '<button type="submit">Оформить заказ</button>';
echo '</form>';

$stmt->close();
$conn->close();
?>
