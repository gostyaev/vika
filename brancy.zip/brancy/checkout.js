document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("checkout-button").addEventListener("click", function () {
        let totalPrice = parseFloat(document.getElementById("total-price").textContent);

        fetch("order.php", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: `total_price=${totalPrice}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                window.location.href = "success.php";
            } else {
                alert(data.message);
            }
        })
        .catch(error => console.error("Ошибка:", error));
    });
});
