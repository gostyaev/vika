<?php
// Подключаем файл для подключения к базе данных
include('connect.php');

// Проверяем, передан ли идентификатор товара
if (isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];

    // SQL запрос для удаления товара
    $sql = "DELETE FROM products WHERE id = ?";

    // Подготовка запроса
    if ($stmt = $conn->prepare($sql)) {
        // Привязываем параметр
        $stmt->bind_param("i", $productId);

        // Выполняем запрос
        if ($stmt->execute()) {
            echo "<p>Товар успешно удален.</p>"; 
        } else {
            echo "<p>Ошибка при удалении товара.</p>";
        }

        // Закрываем подготовленный запрос
        $stmt->close();
    } else {
        echo "<p>Ошибка при подготовке запроса.</p>";
    }
}

// Закрываем соединение с базой данных
$conn->close();
?>
