<?php
session_start();

// Проверка, есть ли сессия пользователя (если нет, то редирект на страницу входа)
if (!isset($_SESSION['user_id'])) {
    header("Location: account-login.php");
    exit();
}

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_auth";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получаем ID пользователя из сессии
$user_id = $_SESSION['user_id'];

// Получаем все товары из корзины текущего пользователя
$sql = "SELECT cart.product_id, cart.quantity, products.price
        FROM cart
        JOIN products ON cart.product_id = products.id
        WHERE cart.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Если корзина пустая, не оформляем заказ
if ($result->num_rows == 0) {
    echo "Ваша корзина пуста.";
    exit();
}

// Рассчитываем общую стоимость заказа
$total_price = 0;
while ($row = $result->fetch_assoc()) {
    $total_price += $row['price'] * $row['quantity'];
}

// Добавляем заказ в таблицу заказов
$sql = "INSERT INTO orders (user_id, total_price, status) VALUES (?, ?, 'pending')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("id", $user_id, $total_price);
$stmt->execute();

// Получаем ID нового заказа
$order_id = $stmt->insert_id;

// Переносим товары из корзины в заказ
while ($row = $result->fetch_assoc()) {
    $product_id = $row['product_id'];
    $quantity = $row['quantity'];

    $sql = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iii", $order_id, $product_id, $quantity);
    $stmt->execute();
}

// Очищаем корзину пользователя
$sql = "DELETE FROM cart WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();

echo "Заказ успешно оформлен. Ваш номер заказа: " . $order_id;

// Закрываем соединение с базой данных
$stmt->close();
$conn->close();
?>
