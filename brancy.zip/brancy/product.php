<?php
session_start(); // Стартуем сессию

// Проверяем, авторизован ли пользователь
if (!isset($_SESSION["user_id"])) {
    header("Location: index.php");
    exit();
}




// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_auth";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Добавление товара
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $old_price = $_POST['old_price'];
    $image_url = $_FILES['image']['name'];

    $upload_dir = 'assets/images/shop/';
    $upload_file = $upload_dir . basename($_FILES['image']['name']);
    
    if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_file)) {
        $sql = "INSERT INTO products (name, description, price, old_price, image_url) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdss", $name, $description, $price, $old_price, $image_url);
        $stmt->execute();
        $stmt->close();
    }
}

// Удаление товара
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_product'])) {
    $product_id = $_POST['product_id'];
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->close();
}

// Получение списка товаров
$sql = "SELECT * FROM products";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Brancy</title>

    <style>
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            justify-content: center;
            align-items: center;
        }
        .modal-content {
            background: white;
            padding: 20px;
            border-radius: 10px;
            width: 300px;
            text-align: center;
        }
        .close {
            float: right;
            cursor: pointer;
            font-size: 20px;
        }
        .btn {
            padding: 10px;
            margin: 5px;
            border: none;
            cursor: pointer;
        }
        .btn-primary { background: blue; color: white; }
        .btn-danger { background: red; color: white; }
    </style>

    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="Brancy - Cosmetic & Beauty Salon Website Template">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="bootstrap, ecommerce, ecommerce html, beauty, cosmetic shop, beauty products, cosmetic, beauty shop, cosmetic store, shop, beauty store, spa, cosmetic, cosmetics, beauty salon" />
    <meta name="author" content="codecarnival" />

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="./assets/images/favicon.webp">

    <!-- CSS (Font, Vendor, Icon, Plugins & Style CSS files) -->

    <!-- Font CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Vendor CSS (Bootstrap & Icon Font) -->
    <link rel="stylesheet" href="./assets/css/vendor/bootstrap.min.css">

    <!-- Plugins CSS (All Plugins Files) -->
    <link rel="stylesheet" href="assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="assets/css/plugins/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/plugins/fancybox.min.css">
    <link rel="stylesheet" href="assets/css/plugins/range-slider.css">
    <link rel="stylesheet" href="assets/css/plugins/nice-select.css">

    <!-- Style CSS -->
    <link rel="stylesheet" href="./assets/css/style.min.css">

</head>

<body>

    <!--== Wrapper Start ==-->
    <div class="wrapper">

        <!--== Start Header Wrapper ==-->
        <header class="header-area sticky-header header-transparent">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-5 col-lg-2 col-xl-1">
                        <div class="header-logo">
                            <a href="index.html">
                                <img class="logo-main" src="assets/images/logo.webp" width="95" height="68" alt="Logo" />
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-xl-7 d-none d-lg-block">
                        <div class="header-navigation ps-7">
                            <ul class="main-nav justify-content-start">
                                <li class="has-submenu"><a href="index.html">Главная</a>
                                </li>
                                <li class="has-submenu position-static"><a href="product.html">Каталог</a>
                                        </li>
                                </li>
                                <li class="has-submenu position-static"><a href="cart.php">Корзина</a>
                                        </li>
                                </li>
                                <li class="has-submenu"><a href="account-login.html">Прочее</a>
                                    <ul class="submenu-nav">
                                        <li><a href="account-login.html">Аккаунт</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-7 col-lg-3 col-xl-4">
                        <div class="header-action justify-content-end">
                            <button class="header-action-btn ms-0" type="button" data-bs-toggle="offcanvas" data-bs-target="#AsideOffcanvasSearch" aria-controls="AsideOffcanvasSearch">
                                <span class="icon">
                  <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <rect class="icon-rect" width="30" height="30" fill="url(#pattern1)"/>
                    <defs>
                      <pattern id="pattern1" patternContentUnits="objectBoundingBox" width="1" height="1">
                        <use xlink:href="#image0_504:11" transform="scale(0.0333333)"/>
                      </pattern>
                      <image id="image0_504:11" width="30" height="30" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABiUlEQVRIie2Wu04CQRSGP0G2EUtIbHwA8B3EQisLIcorEInx8hbEZ9DKy6toDI1oAgalNFpDoYWuxZzJjoTbmSXERP7kZDbZ859vdmb27MJcf0gBUAaugRbQk2gBV3IvmDa0BLwA4Zh4BorTACaAU6fwPXAI5IAliTxwBDScvJp4vWWhH0BlTLEEsC+5Fu6lkgNdV/gKDnxHCw2I9rSiNQNV8baBlMZYJtpTn71KAg9SY3dUYn9xezLPgG8P8BdwLteq5X7CzDbnAbXKS42WxtQVUzoGeFlqdEclxXrnhmhhkqR+8KuMqzHA1vumAddl3IwB3pLxVmOyr1NjwKQmURJ4lBp7GmOAafghpg1qdSDeDrCoNReJWmZB4dsAPsW7rYVa1Rx4FbOEw5TEPKmFvgMZX3DCgYeYNniMaQ5piTXghGhPLdTmZ33hYNpem98f/UHRwSxvhqhXx4anMA3/EmhiOlJPJnSBOb3uQcpOE65VhujPpAms/Bu4u+x3swRbeB24mTV4LgB+AFuLedkPkcmmAAAAAElFTkSuQmCC"/>
                    </defs>
                  </svg>
                </span>
                            </button>

                            <button class="header-action-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#AsideOffcanvasCart" aria-controls="AsideOffcanvasCart">
                                <span class="icon">
                  <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <rect class="icon-rect" width="30" height="30" fill="url(#pattern2)"/>
                    <defs>
                      <pattern id="pattern2" patternContentUnits="objectBoundingBox" width="1" height="1">
                        <use xlink:href="#image0_504:9" transform="scale(0.0333333)"/>
                      </pattern>
                      <image id="image0_504:9" width="30" height="30" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABFUlEQVRIie2VMU7DMBSGvwAqawaYuAmKxCW4A1I5Qg4AA93KBbp1ZUVUlQJSVVbCDVhgzcTQdLEVx7WDQ2xLRfzSvzzb+d6zn2MYrkugBBYevuWsHKiFn2JBMwH8Bq6Aw1jgBwHOYwGlPgT4LDZ4I8BJDNiEppl034UEJ8DMAJ0DByHBACPgUYEugePQUKkUWAmnsaB/Ry/YO9aXCwlT72AdrqaWEohwBWxSwc8ReIVtYIr5bM5pXqO+Men7rozGlkVSv4lJj1WQfsbvXVkNVNk1eEK4ik9/yuwzAPhLh5iuU4jtftMDR4ZJJXChxTJ2H3zXGDgWc43/X2Wro8G81a8u2fXU2nXiLVAxvNIKuPGW/r/2SltF+a3Rkw4pmwAAAABJRU5ErkJggg=="/>
                    </defs>
                  </svg>
                </span>
                            </button>

                            <a class="header-action-btn" href="account-login.php">
                                <span class="icon">
                  <svg width="30" height="30" viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                    <rect class="icon-rect" width="30" height="30" fill="url(#pattern3)"/>
                    <defs>
                      <pattern id="pattern3" patternContentUnits="objectBoundingBox" width="1" height="1">
                        <use xlink:href="#image0_504:10" transform="scale(0.0333333)"/>
                      </pattern>
                      <image id="image0_504:10" width="30" height="30" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAABmJLR0QA/wD/AP+gvaeTAAABEUlEQVRIie3UMUoDYRDF8Z8psqUpLBRrBS+gx7ATD6E5iSjeQQ/gJUzEwmChnZZaKZiQ0ljsLkhQM5/5Agr74DX7DfOfgZ1Hoz+qAl30Marcx2H1thCtY4DJN76parKqmAH9DM+6eTcArX2QE3yVAO7lBA8TwMNIw6UgeJI46My+rWCjUQL0LVIUBd8lgEO1UfBZAvg8oXamCuWNRu64nRNMmUo/wReSXLXayoDoKc9miMvqW/ZNG2VRNLla2MYudrCFTvX2intlnl/gGu/zDraGYzyLZ/UTjrD6G2AHpxgnAKc9xgmWo9BNPM4BnPYDNiLg24zQ2oNpyFdZvRKZLlGhnvvKPzXXti/Yy7hEo3+iD9EHtgdqxQnwAAAAAElFTkSuQmCC"/>
                    </defs>
                  </svg>
                </span>
                            </a>

                            <button class="header-menu-btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#AsideOffcanvasMenu" aria-controls="AsideOffcanvasMenu">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--== End Header Wrapper ==-->

        <main class="main-content">

            <!--== Start Page Header Area Wrapper ==-->
            <section class="page-header-area pt-10 pb-9" data-bg-color="#FFF3DA">
                <div class="container">
                    <div class="row">
                        <div class="col-md-5">
                            <div class="page-header-st3-content text-center text-md-start">
                             
                                
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--== End Page Header Area Wrapper ==-->

            <!--== Start Shop Top Bar Area Wrapper ==-->
            <div class="shop-top-bar-area">
                <div class="container">
                    <div class="shop-top-bar">
                        <select class="select-shoing">
                            <option data-display="Сортировать">Каталог</option>
                            <option value="1">.....</option>
                            <option value="2">.....</option>
                            <option value="3">.....</option>
                            <option value="4">.....</option>
                            <option value="5">.....</option>
                            <option value="6">.....</option>
                        </select>
                    </div>
                </div>
            </div>
            <!--== End Shop Top Bar Area Wrapper ==-->

            <!--== Start Product Category Area Wrapper ==-->
            
            <!--== End Product Category Area Wrapper ==-->

            <div class="container mt-8">
                <div class="row g-3 g-sm-4 g-lg-3">
                <?php
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_auth";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Проверка, что пользователь залогинен
if (!isset($_SESSION['user_id'])) {
    echo "<p>Пожалуйста, авторизуйтесь, чтобы добавлять товары в корзину.</p>";
    exit;
}

// Обработка добавления товара в корзину
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $user_id = $_SESSION['user_id'];
    $product_id = $_POST['product_id'];
    $quantity = 1; // по умолчанию добавляем 1 товар, но можно изменить логику

    // Проверяем, есть ли уже этот товар в корзине
    $sql_check = "SELECT * FROM cart WHERE user_id = ? AND product_id = ?";
    $stmt_check = $conn->prepare($sql_check);
    
    if ($stmt_check) {
        $stmt_check->bind_param("ii", $user_id, $product_id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            // Если товар уже есть в корзине, увеличиваем его количество
            $sql_update = "UPDATE cart SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?";
            $stmt_update = $conn->prepare($sql_update);
            
            if ($stmt_update) {
                $stmt_update->bind_param("ii", $user_id, $product_id);
                $stmt_update->execute();
                $stmt_update->close();
            } else {
                echo "<p>Ошибка при обновлении корзины.</p>";
            }
        } else {
            // Если товара нет в корзине, добавляем его
            $sql_insert = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            
            if ($stmt_insert) {
                $stmt_insert->bind_param("iii", $user_id, $product_id, $quantity);
                $stmt_insert->execute();
                $stmt_insert->close();
            } else {
                echo "<p>Ошибка при добавлении товара в корзину.</p>";
            }
        }

        $stmt_check->close();
    } else {
        echo "<p>Ошибка при проверке корзины.</p>";
    }
}
// Обработка удаления товара
if (isset($_GET['delete_product_id'])) {
    $delete_product_id = $_GET['delete_product_id'];

    // Удаляем товар из базы данных
    $sql_delete = "DELETE FROM products WHERE id = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    
    if ($stmt_delete) {
        $stmt_delete->bind_param("i", $delete_product_id);
        $stmt_delete->execute();
        $stmt_delete->close();
        echo "<p>Товар успешно удален.</p>";
    } else {
        echo "<p>Ошибка при удалении товара.</p>";
    }
}
// Запрос к базе данных для получения всех товаров
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<div class="row mb-n4 mb-sm-n10 g-3 g-sm-6">';
    while ($product = $result->fetch_assoc()) {
        $imagePath = file_exists($product['image_url']) ? $product['image_url'] : 'assets/images/shop/default-product.jpg';
        echo '<div class="col-6 col-lg-4 mb-4 mb-sm-8">';
        echo '    <div class="product-item">';
        echo '        <div class="product-thumb">';
        echo '            <a class="d-block" href="#">';
        echo '                <img src="' . $imagePath . '" width="370" height="450" alt="' . $product['name'] . '">';
        echo '            </a>';
        echo '            <span class="flag-new">new</span>';
        echo '        </div>';
        echo '        <div class="product-info">';
        echo '            <h4 class="title"><a href="#">' . $product['name'] . '</a></h4>';
        echo '            <div class="prices">';
        echo '                <span class="price">' . $product['price'] . ' р</span>';
        echo '                <span class="price-old">' . $product['old_price'] . '</span>';
        echo '            </div>';
        echo '        </div>';
        echo '        <form action="" method="POST" class="add-to-cart-form">';
        echo '            <input type="hidden" name="product_id" value="' . $product['id'] . '">';
        echo '            <button type="submit" name="add_to_cart" class="add-to-cart-btn">Добавить в корзину</button>';
        echo '        </form>';
        echo '    </div>';
        echo '</div>';
    // Кнопка удаления товара для администраторов
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        echo '        <a href="?delete_product_id=' . $product['id'] . '" class="delete-product-btn">Удалить</a>';
    }

    echo '    </div>';
    echo '</div>';
}
echo '</div>';
} else {
echo "<p>Нет товаров для отображения.</p>";
}

// Для администратора
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
    <button id="toggleForm">Добавить товар</button>
    <div id="productForm" style="display: none;">
        <h3>Добавить новый товар</h3>
        <form method="POST" enctype="multipart/form-data">
            <div>
                <label for="name">Название:</label>
                <input type="text" name="name" id="name" required>
            </div>
            <div>
                <label for="description">Описание:</label>
                <textarea name="description" id="description" required></textarea>
            </div>
            <div>
                <label for="price">Цена:</label>
                <input type="number" name="price" id="price" step="0.01" required>
            </div>
            <div>
                <label for="old_price">Старая цена:</label>
                <input type="number" name="old_price" id="old_price" step="0.01">
            </div>
            <div>
                <label for="image">Изображение:</label>
                <input type="file" name="image" id="image" required>
            </div>
            <div>
                <button type="submit" name="add_product">Добавить товар</button>
            </div>
        </form>
    </div>

    <script>
        const toggleButton = document.getElementById('toggleForm');
        const productForm = document.getElementById('productForm');

        toggleButton.addEventListener('click', function() {
            if (productForm.style.display === 'none') {
                productForm.style.display = 'block'; // Показываем форму
            } else {
                productForm.style.display = 'none'; // Скрываем форму
            }
        });
    </script>
<?php endif; ?>

<?php
// Закрываем подключение
$conn->close();
?>






                </div>
            </div>

        </main>

        <!--== Footer Start ==-->
        
        <!--== Footer End ==-->

    </div>
    <!--== Wrapper End ==-->
    <script>
document.addEventListener('DOMContentLoaded', function () {
    // Получаем все кнопки "Добавить в корзину"
    const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function () {
            const productId = this.getAttribute('data-product-id');
            
            // Отправляем POST-запрос через AJAX
            fetch('add_to_cart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    product_id: productId,
                    quantity: 1, // если нужно добавить возможность выбора количества
                })
            })
            .then(response => response.text())
            .then(data => {
                console.log(data); // Проверяем ответ
                alert('Товар добавлен в корзину');
            })
            .catch(error => {
                console.error('Ошибка:', error);
            });
        });
    });
});

<script>
    document.querySelectorAll('.add-to-cart-btn').forEach(button => {
        button.addEventListener('click', function() {
            var productId = this.getAttribute('data-product-id');
            
            // Проверка на случай, если productId пустой
            if (!productId) {
                alert('Ошибка: Не указан product_id');
                return;
            }

            // Отправляем запрос на добавление товара в корзину
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'add_to_cart.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    alert(xhr.responseText);  // Ответ от сервера
                }
            };
            xhr.send('product_id=' + productId);  // Отправляем ID товара
        });
    });
</script>

</script>
    <!-- JS Files -->
    <script src="assets/js/vendor/modernizr-3.11.2.min.js"></script>
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <script src="assets/js/plugins/swiper-bundle.min.js"></script>
    <script src="assets/js/plugins/nice-select.min.js"></script>
    <script src="assets/js/plugins/fancybox.min.js"></script>
    <script src="assets/js/plugins/range-slider.min.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
