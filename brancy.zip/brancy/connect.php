<?php
$servername = "localhost";
$username = "root"; // укажите ваше имя пользователя
$password = ""; // укажите ваш пароль, если он есть
$dbname = "user_auth"; // укажите имя вашей базы данных

// Создаем подключение
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверяем соединение
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
