<?php
session_start();

// Проверка, есть ли сессия пользователя
if (!isset($_SESSION['user_id'])) {
    header("Location: account-login.php");
    exit();
}

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user_auth";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user_id'];

// Получаем все товары из корзины пользователя
$sql = "SELECT cart.product_id, cart.quantity, products.price 
        FROM cart
        JOIN products ON cart.product_id = products.id
        WHERE cart.user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Рассчитываем общую стоимость
    $total_price = 0;
    while ($row = $result->fetch_assoc()) {
        $total_price += $row['price'] * $row['quantity'];
    }

    // Добавляем заказ в таблицу orders
    $sql_order = "INSERT INTO orders (user_id, total_price) VALUES (?, ?)";
    $stmt_order = $conn->prepare($sql_order);
    $stmt_order->bind_param("id", $user_id, $total_price);
    $stmt_order->execute();
    $order_id = $stmt_order->insert_id;  // Получаем ID нового заказа

    // Добавляем товары в таблицу order_items
    $result->data_seek(0);  // Сбрасываем указатель на начало результата
    while ($row = $result->fetch_assoc()) {
        $product_id = $row['product_id'];
        $quantity = $row['quantity'];
        $price = $row['price'];

        $sql_order_items = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                            VALUES (?, ?, ?, ?)";
        $stmt_order_items = $conn->prepare($sql_order_items);
        $stmt_order_items->bind_param("iiid", $order_id, $product_id, $quantity, $price);
        $stmt_order_items->execute();
    }

    // Очищаем корзину пользователя после оформления заказа
    $sql_clear_cart = "DELETE FROM cart WHERE user_id = ?";
    $stmt_clear_cart = $conn->prepare($sql_clear_cart);
    $stmt_clear_cart->bind_param("i", $user_id);
    $stmt_clear_cart->execute();

    // Перенаправляем на страницу подтверждения
    header("Location: order-confirmation.php?order_id=" . $order_id);
    exit();
} else {
    echo "Ваша корзина пуста.";
}

$stmt->close();
$conn->close();
?>
